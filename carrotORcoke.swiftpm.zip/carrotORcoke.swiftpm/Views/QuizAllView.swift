//
//  SwiftUIView.swift
//  
//
//  Created by alex on 2023/08/22.
//

import SwiftUI

struct QuizAllView: View {
    var body: some View {
        
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        
        
        
    }
}

struct QuizAllView_Previews: PreviewProvider {
    static var previews: some View {
        QuizAllView()
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
